#include"beep.h"
//#include"carbaseic.h"

void beep_start(){
 
   FM=0;
}
void beep_Stop(){
 
   FM=1;
}
