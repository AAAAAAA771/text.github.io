#include "signal.h"
void cal_on(void);
void cal_off(void);
void recovery_factory(void);
void IIC_ADDR_Change(void);
void CMP_OFFS(void);

