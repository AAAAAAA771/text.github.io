#include  <stdio.h>   //Keil library
#include  <REG51.H>
#include  <INTRINS.H>
//typedef unsigned short WORD;
void delay(unsigned int k);
void Delay5ms();
void Delay5us();
void delay_10ms();
